import base64
import json
import os
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from google.cloud import firestore
from datetime import datetime, timezone
from flask import Request

# ─── Ініціалізація (один раз при cold start) ───

_db = firestore.Client()

def _create_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=3, backoff_factor=2,
        status_forcelist=[503],
        allowed_methods=["POST"],
        raise_on_status=False
    )
    session.mount("https://", HTTPAdapter(max_retries=retry))
    return session

_http = _create_session()

EMAIL_SENDER_URL = os.environ.get("EMAIL_SENDER_URL")
ADMIN_EMAIL      = os.environ.get("ADMIN_EMAIL")
PROJECT_ID       = os.environ.get("GCP_PROJECT")

# ─── Idempotency helpers ───
def _is_duplicate(event_id: str) -> bool:
    doc = _db.collection("processed_notifications").document(event_id).get()
    return doc.exists

def _mark_processed(event_id: str, event_type: str):
    _db.collection("processed_notifications").document(event_id).set({
        "processed_at": datetime.now(timezone.utc).isoformat(),
        "event_type":   event_type
    })

# ─── REST-виклик email-sender ───
def _call_email_sender(endpoint: str, payload: dict, event_id: str):
    """
    Викликає email-sender функцію по REST.
    Повертає True при успіху, False при клієнтській помилці,
    кидає виняток при серверній помилці (щоб Pub/Sub зробив retry).
    """
    url = f"{EMAIL_SENDER_URL}{endpoint}"

    try:
        resp = _http.post(url, json=payload, timeout=30)
    except requests.exceptions.Timeout:
        raise RuntimeError(f"email-sender timeout | event_id={event_id}")
    except requests.exceptions.ConnectionError as e:
        raise RuntimeError(f"email-sender unreachable: {e} | event_id={event_id}")

    if resp.status_code == 200:
        print(f"[INFO] Email sent | event_id={event_id}")
        return True
    elif 400 <= resp.status_code < 500:
        # Клієнтська помилка — не кидаємо виняток, не робимо retry
        print(f"[ERROR] Bad request to email-sender: {resp.text[:200]} | event_id={event_id}")
        return False
    else:
        # Серверна помилка — кидаємо виняток → Pub/Sub зробить retry
        raise RuntimeError(
            f"email-sender returned {resp.status_code}: "
            f"{resp.text[:200]} | event_id={event_id}"
        )

# ─── Обробники подій ───
def _dispatch_booking_created(event: dict, event_id: str):
    payload = {
        "recipient":    event["user_id"],
        "user_name":    event.get("user_name", "Клієнт"),
        "booking_id":   event["booking_id"],
        "apartment_id": event["apartment_id"],
        "description":  event.get("description", "не вказано"),
        "rooms":        event.get("rooms", "не вказано"),
        "address":      event.get("address", "не вказано"),
        "start_date":   event["start_date"],
        "end_date":     event["end_date"],
        "price":        event.get('price', '—')
    }
    _call_email_sender("/send-booking-email", payload, event_id)

def _dispatch_apartment_added(event: dict, event_id: str):
    if not ADMIN_EMAIL:
        print("[WARNING] ADMIN_EMAIL not set — skipping apartment_added notification")
        return

    payload = {
        "recipient": ADMIN_EMAIL,
        "subject":   f"🏠 Нова квартира: {event.get('address', event.get('apartment_id'))}",
        "text": (
            f"Додано нову квартиру.\n"
            f"ID: {event.get('apartment_id')}\n"
            f"Адреса: {event.get('address', 'не вказано')}\n"
            f"Кількість кімнат: {event.get('rooms', 'не вказано')}\n"
            f"Опис: {event.get('description', 'не вказано')}\n"
            f"Ціна/день: {event.get('price', '—')} UAH"
        )
    }
    _call_email_sender("/send-email", payload, event_id)

# ─── Головний обробник — HTTP сигнатура ───
def main(request: Request):
    """
    Точка входу для HTTP-тригера (Pub/Sub push-підписка).

    Pub/Sub надсилає POST з JSON-тілом:
    {
      "message": {
        "data": "<base64>",
        "messageId": "...",
        "attributes": {}
      },
      "subscription": "projects/.../subscriptions/..."
    }

    Коди відповіді:
      200 → Pub/Sub ACK (повідомлення оброблено або навмисно відкинуто)
      500 → Pub/Sub NACK → retry → після max_delivery_attempts → DLQ
    """

    # 1. Валідація конверта Pub/Sub push
    envelope = request.get_json(silent=True)
    if not envelope or "message" not in envelope:
        print("[WARNING] Invalid Pub/Sub push envelope")
        # 400 → Pub/Sub вважатиме це постійною помилкою і теж відправить в DLQ
        return "Bad Request: missing message envelope", 400

    message  = envelope["message"]
    event_id = message.get("messageId") or message.get("message_id", "unknown")

    # 2. Порожнє повідомлення — ACK (не retry)
    if "data" not in message:
        print(f"[WARNING] Empty Pub/Sub message | event_id={event_id}")
        return "OK", 200

    # 3. Idempotency check
    if _is_duplicate(event_id):
        print(f"[INFO] Duplicate message skipped | event_id={event_id}")
        return "OK", 200  # ACK — вже оброблено раніше

    # 4. Декодування та парсинг
    try:
        raw     = base64.b64decode(message["data"]).decode("utf-8")
        payload = json.loads(raw)
    except (ValueError, json.JSONDecodeError) as e:
        # Битий формат — retry не допоможе → ACK і логуємо
        print(f"[ERROR] Invalid message format: {e} | event_id={event_id}")
        return "OK", 200

    event_type = payload.get("event_type")
    print(f"[INFO] Processing event_type={event_type} | event_id={event_id}")

    # 5. Маршрутизація з обробкою помилок
    try:
        if event_type == "booking_created":
            _dispatch_booking_created(payload, event_id)
        elif event_type == "apartment_added":
            _dispatch_apartment_added(payload, event_id)
        else:
            # Невідомий тип — ACK, не retry (retry не виправить)
            print(f"[WARNING] Unknown event_type={event_type} | event_id={event_id}")
            return "OK", 200

    except RuntimeError as e:
        # Серверна помилка email-sender або мережева недоступність
        # → 500 → Pub/Sub NACK → retry → після 5 спроб → DLQ
        print(f"[ERROR] {e}")
        return f"Internal error: {e}", 500

    # 6. Записуємо факт успішної обробки
    _mark_processed(event_id, event_type)

    return "OK", 200